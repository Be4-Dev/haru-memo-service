package com.haruMemo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class HaruMemoApplication

fun main(args: Array<String>) {
	runApplication<HaruMemoApplication>(*args)
}
