rootProject.name = "haruMemo"
